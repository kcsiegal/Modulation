package finalgame;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class LevelSelect implements MouseListener
{
	public LevelSelect()
	{
		
	}

	@Override
	public void mouseClicked(MouseEvent e) 
	{
		// TODO Auto-generated method stub
		/*if(e.getLocationOnScreen() == loc of newgame button)
		{
			PlayLevels pl = new PlayLevels(1);
		}
		if(e.getLocationOnScreen() == loc of level select button)
		{
			LevelSelect ls = new LevelSelect();
		}
		if(e.getLocationOnScreen() == loc of Instructions button)
		{
			Instructions inst = new Instructions();
		}
		if(e.getLocationOnScreen() == loc of quit button)
		{
			quit();
		}*/
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	
}
